PROXY_ADDRESS = ("localhost", 8000)
BUFF_SIZE = 96
HEAD_END_SEQ = "\r\n\r\n"
HEAD_ENDLINE = "\r\n"
